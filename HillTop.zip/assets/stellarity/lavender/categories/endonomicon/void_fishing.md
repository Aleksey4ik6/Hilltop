```json
{
  "title": "Void Fishing",
  "icon": "minecraft:stick[item_model=\"stellarity:fisher_of_voids\"]"
}
```
