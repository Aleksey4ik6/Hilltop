```json
{
  "title": "Ancient Wooden Sword",
  "icon": "minecraft:stick[item_model=\"stellarity:ancient_wooden_sword\"]",
  "category": "stellarity:weapons",
  "associated_items": []
}
```

![Tamaris](stellarity:textures/item/ancient_wooden_sword.png,fit)

;;;;;

